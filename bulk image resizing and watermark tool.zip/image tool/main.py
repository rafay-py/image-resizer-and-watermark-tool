import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.ttk import Progressbar, Scale
from PIL import Image, ImageDraw, ImageFont
import os

# Function to select the input folder
def select_folder():
    folder = filedialog.askdirectory()
    if folder:
        input_folder_entry.delete(0, tk.END)
        input_folder_entry.insert(0, folder)

# Function to select output folder
def select_output_folder():
    folder = filedialog.askdirectory()
    if folder:
        output_folder_entry.delete(0, tk.END)
        output_folder_entry.insert(0, folder)

# Processing the image
def process_image():
    input_folder = input_folder_entry.get()
    output_folder = output_folder_entry.get()
    resize_width = resize_width_entry.get()
    resize_height = resize_height_entry.get()
    watermark_text = watermark_entry.get()
    watermark_size = watermark_size_scale.get()
    watermark_opacity = watermark_opacity_scale.get()

    if not input_folder or not output_folder:
        messagebox.showerror("Error", "Please select input and output folder")
        return

    try:
        resize_width = int(resize_width)
        resize_height = int(resize_height)
    except ValueError:
        messagebox.showerror("Error", "Please enter valid dimensions for resizing")
        return

    try:
        total_images = len([f for f in os.listdir(input_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif'))])
        if total_images == 0:
            messagebox.showwarning("Warning", "No valid images found in the input folder")
            return

        progress_bar["maximum"] = total_images
        processed_count = 0

        for filename in os.listdir(input_folder):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                input_path = os.path.join(input_folder, filename)
                output_path = os.path.join(output_folder, filename)

                try:
                    img = Image.open(input_path).convert("RGBA")
                    img = img.resize((resize_width, resize_height), Image.Resampling.LANCZOS)

                    # Add watermark
                    if watermark_text:
                        watermark_layer = Image.new("RGBA", img.size, (255, 255, 255, 0))
                        draw = ImageDraw.Draw(watermark_layer)

                        font_path = "arial.ttf"  # Ensure the font path is correct
                        font = ImageFont.truetype(font_path, watermark_size)
                        text_width, text_height = draw.textbbox((0, 0), watermark_text, font=font)[2:]
                        position = ((img.width - text_width) // 2, (img.height - text_height) // 2)

                        # Apply transparency
                        watermark_color = (255, 255, 255, int(255 * (watermark_opacity / 100)))
                        draw.text(position, watermark_text, fill=watermark_color, font=font)

                        img = Image.alpha_composite(img, watermark_layer)

                    img = img.convert("RGB")  # Convert back to RGB for saving
                    img.save(output_path)
                    processed_count += 1

                    # Update progress bar
                    progress_bar["value"] = processed_count
                    root.update_idletasks()
                except Exception as e:
                    print(f"Failed to process {filename}: {e}")

        messagebox.showinfo("Success", "Processing complete!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Tkinter setup
root = tk.Tk()
root.title("Bulk Image Resizer and Watermark")
root.resizable(False, False)

# Navbar
navbar_frame = tk.Frame(root, bg="lightblue", height=40)
navbar_frame.grid(row=0, column=0, columnspan=3, sticky="ew")
navbar_label = tk.Label(navbar_frame, text="Bulk Image Resizer and Watermark", bg="lightblue", font=("Arial", 14, "bold"))
navbar_label.pack(pady=5)

# Input folder selection
input_folder_label = tk.Label(root, text="Input Folder:")
input_folder_label.grid(row=1, column=0, padx=10, pady=10)
input_folder_entry = tk.Entry(root, width=40)
input_folder_entry.grid(row=1, column=1, padx=10, pady=10)
input_folder_button = tk.Button(root, text="Browse", command=select_folder, background="grey")
input_folder_button.grid(row=1, column=2, padx=10, pady=10)

# Output folder selection
output_folder_label = tk.Label(root, text="Output Folder:")
output_folder_label.grid(row=2, column=0, padx=10, pady=10)
output_folder_entry = tk.Entry(root, width=40)
output_folder_entry.grid(row=2, column=1, padx=10, pady=10)
output_folder_button = tk.Button(root, text="Browse", command=select_output_folder, background="grey")
output_folder_button.grid(row=2, column=2, padx=10, pady=10)

# Resize option
resize_label = tk.Label(root, text="Resize Dimensions (width x height)")
resize_label.grid(row=3, column=0, padx=10, pady=10)
resize_width_entry = tk.Entry(root)
resize_width_entry.grid(row=3, column=1, padx=10, pady=10)
resize_width_entry.insert(0, "800")
resize_height_entry = tk.Entry(root)
resize_height_entry.grid(row=3, column=2, padx=10, pady=10)
resize_height_entry.insert(0, "600")

# Watermark text
watermark_label = tk.Label(root, text="Watermark text")
watermark_label.grid(row=4, column=0, padx=10, pady=10)
watermark_entry = tk.Entry(root, width=40)
watermark_entry.grid(row=4, column=1, padx=10, pady=10)

# Watermark size slider
watermark_size_label = tk.Label(root, text="Watermark Size")
watermark_size_label.grid(row=5, column=0, padx=10, pady=10)
watermark_size_scale = tk.Scale(root, from_=10, to=100, orient="horizontal")
watermark_size_scale.grid(row=5, column=1, padx=10, pady=10)
watermark_size_scale.set(20)

# Watermark opacity slider
watermark_opacity_label = tk.Label(root, text="Watermark Opacity (%)")
watermark_opacity_label.grid(row=6, column=0, padx=10, pady=10)
watermark_opacity_scale = tk.Scale(root, from_=0, to=100, orient="horizontal")
watermark_opacity_scale.grid(row=6, column=1, padx=10, pady=10)
watermark_opacity_scale.set(50)

# Process button
process_button = tk.Button(root, text="Process Images", command=process_image, background="red")
process_button.grid(row=7, column=0, columnspan=3, pady=20)

# Progress bar
progress_bar = Progressbar(root, length=300, mode="determinate")
progress_bar.grid(row=8, column=0, columnspan=3, padx=10, pady=10)

root.mainloop()
